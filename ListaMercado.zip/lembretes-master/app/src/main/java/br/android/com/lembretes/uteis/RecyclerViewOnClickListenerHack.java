package br.android.com.lembretes.uteis;

import android.support.annotation.NonNull;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public interface RecyclerViewOnClickListenerHack {
    boolean OnCreateOptionsMenu(Menu menu);

    boolean OnOptionsItemSelected(@NonNull MenuItem item);

    public void onClickListener(View view, int position);
    public void onLongPressClickListener(View view, int position);
}
